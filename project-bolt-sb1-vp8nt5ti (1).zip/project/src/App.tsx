import React, { useState } from 'react';
import { Search, Globe2, HelpCircle, Clock, LogIn, ChevronDown, MapPin, Smartphone, CircleIcon, DollarSign } from 'lucide-react';

function App() {
  const [searchQuery, setSearchQuery] = useState('');
  const [isLanguageMenuOpen, setIsLanguageMenuOpen] = useState(false);
  const [isCurrencyMenuOpen, setIsCurrencyMenuOpen] = useState(false);

  const languages = [
    { code: 'en-AU', name: 'English (Australia)', flag: '🇦🇺' },
    { code: 'en-CA', name: 'English (Canada)', flag: '🇨🇦' },
    { code: 'en-HK', name: 'English (Hong Kong, SAR)', flag: '🇭🇰' },
    { code: 'en-IN', name: 'English (India)', flag: '🇮🇳' },
    { code: 'en-MY', name: 'English (Malaysia)', flag: '🇲🇾' },
    { code: 'en-NZ', name: 'English (New Zealand)', flag: '🇳🇿' },
    { code: 'en-PH', name: 'English (Philippines)', flag: '🇵🇭' },
    { code: 'en-SG', name: 'English (Singapore)', flag: '🇸🇬' },
    { code: 'en-US', name: 'English (US)', flag: '🇺🇸' },
    { code: 'en', name: 'English (International)', flag: '🌐' },
    { code: 'zh-CN', name: '简体中文', flag: '🇨🇳' },
    { code: 'zh-TW', name: '繁體中文', flag: '🇹🇼' },
    { code: 'ja', name: '日本語', flag: '🇯🇵' },
    { code: 'ko', name: '한국어', flag: '🇰🇷' },
    { code: 'th', name: 'ภาษาไทย', flag: '🇹🇭' },
    { code: 'vi', name: 'Tiếng Việt', flag: '🇻🇳' },
    { code: 'id', name: 'Bahasa Indonesia', flag: '🇮🇩' },
    { code: 'ms', name: 'Bahasa Melayu', flag: '🇲🇾' },
    { code: 'fr', name: 'Français', flag: '🇫🇷' },
    { code: 'es', name: 'Español', flag: '🇪🇸' },
    { code: 'de', name: 'Deutsch', flag: '🇩🇪' },
    { code: 'it', name: 'Italiano', flag: '🇮🇹' },
    { code: 'ru', name: 'Русский', flag: '🇷🇺' },
  ];

  const popularCurrencies = [
    { code: 'USD', name: 'U.S. Dollar' },
    { code: 'SGD', name: 'Singapore Dollar' },
    { code: 'HKD', name: 'Hong Kong Dollar' },
    { code: 'PHP', name: 'Philippine Peso' },
    { code: 'MYR', name: 'Malaysian Ringgit' },
    { code: 'TWD', name: 'New Taiwan Dollar' },
    { code: 'CNY', name: 'Chinese Yuan' },
    { code: 'KRW', name: 'Korean Won' },
    { code: 'ILS', name: 'Israeli Shekel' },
  ];

  const moreCurrencies = [
    { code: 'AED', name: 'U.A.E Dirham' },
    { code: 'AUD', name: 'Australian Dollar' },
    { code: 'CAD', name: 'Canadian Dollar' },
    { code: 'CHF', name: 'Swiss Franc' },
    { code: 'DKK', name: 'Danish Krone' },
    { code: 'EGP', name: 'Egyptian Pound' },
    { code: 'EUR', name: 'Euro' },
    { code: 'FJD', name: 'Fijian Dollar' },
    { code: 'GBP', name: 'British Pound' },
    { code: 'IDR', name: 'Indonesian Rupiah' },
    { code: 'INR', name: 'Indian Rupee' },
    { code: 'ISK', name: 'Icelandic Krona' },
    { code: 'JOD', name: 'Jordanian Dinar' },
    { code: 'JPY', name: 'Japanese Yen' },
    { code: 'KHR', name: 'Cambodian Riel' },
    { code: 'LAK', name: 'Lao Kip' },
    { code: 'MAD', name: 'Moroccan Dirham' },
    { code: 'MGA', name: 'Malagasy Ariary' },
    { code: 'MOP', name: 'Macau Pataca' },
    { code: 'MUR', name: 'Mauritian Rupee' },
    { code: 'MXN', name: 'Mexican Peso' },
    { code: 'NOK', name: 'Norwegian Krone' },
    { code: 'NZD', name: 'New Zealand Dollar' },
    { code: 'OMR', name: 'Omani Rial' },
    { code: 'QAR', name: 'Qatar Riyal' },
    { code: 'SEK', name: 'Swedish Krona' },
    { code: 'THB', name: 'Thai Baht' },
    { code: 'TRY', name: 'Turkish Lira' },
    { code: 'VND', name: 'Vietnamese Dong' },
    { code: 'ZAR', name: 'South African Rand' },
  ];

  return (
    <div className="min-h-screen">
      {/* Header */}
      <header className="sticky top-0 bg-white shadow-sm z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="flex justify-between items-center py-4">
            {/* Logo */}
            <div className="flex items-center space-x-8">
              <h1 className="text-2xl font-bold relative">
                <span className="bg-gradient-to-r from-orange-500 via-green-500 to-purple-500 bg-clip-text text-transparent">
                  tixtogo
                </span>
                <div className="absolute -inset-1 bg-gradient-to-r from-orange-500 via-green-500 to-purple-500 opacity-30 blur-lg -z-10 rounded-lg" />
              </h1>
              
              {/* Search Bar */}
              <div className="hidden md:flex items-center">
                <div className="relative">
                  <input
                    type="text"
                    placeholder="Search destinations or activities..."
                    className="w-[400px] pl-10 pr-4 py-2 border border-gray-200 rounded-full focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                  />
                  <Search className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
                </div>
              </div>
            </div>

            {/* Navigation */}
            <nav className="hidden lg:flex items-center space-x-8">
              <div className="flex items-center space-x-6 text-sm">
                {/* Language Selector */}
                <div className="relative">
                  <button 
                    className="flex items-center space-x-1 text-gray-600 hover:text-orange-500"
                    onClick={() => setIsLanguageMenuOpen(!isLanguageMenuOpen)}
                  >
                    <Globe2 className="h-4 w-4" />
                    <span>English (US)</span>
                    <ChevronDown className="h-4 w-4" />
                  </button>

                  {/* Language Submenu */}
                  {isLanguageMenuOpen && (
                    <div className="absolute right-0 mt-2 w-80 bg-white rounded-lg shadow-lg border border-gray-100 py-2">
                      <div className="px-4 py-2 border-b border-gray-100">
                        <h3 className="font-semibold text-gray-900">Select your language</h3>
                      </div>
                      <div className="grid grid-cols-2 gap-1 p-2 max-h-[400px] overflow-y-auto">
                        {languages.map((lang) => (
                          <button
                            key={lang.code}
                            className={`flex items-center space-x-2 px-3 py-2 text-sm rounded-md transition-colors
                              ${lang.code === 'en-US' 
                                ? 'text-orange-500 bg-orange-50' 
                                : 'text-gray-600 hover:bg-gray-50'
                              }`}
                            onClick={() => setIsLanguageMenuOpen(false)}
                          >
                            <span className="text-base">{lang.flag}</span>
                            <span>{lang.name}</span>
                          </button>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                {/* Currency Selector */}
                <div className="relative">
                  <button 
                    className="flex items-center space-x-1 text-gray-600 hover:text-orange-500"
                    onClick={() => setIsCurrencyMenuOpen(!isCurrencyMenuOpen)}
                  >
                    <DollarSign className="h-4 w-4" />
                    <span>EUR</span>
                    <ChevronDown className="h-4 w-4" />
                  </button>

                  {/* Currency Submenu */}
                  {isCurrencyMenuOpen && (
                    <div className="absolute right-0 mt-2 w-[480px] bg-white rounded-lg shadow-lg border border-gray-100 py-2">
                      {/* Popular Currencies */}
                      <div className="px-4 py-2 border-b border-gray-100">
                        <h3 className="font-semibold text-gray-900">Popular currencies</h3>
                      </div>
                      <div className="grid grid-cols-3 gap-1 p-2">
                        {popularCurrencies.map((currency) => (
                          <button
                            key={currency.code}
                            className="flex items-center space-x-2 px-3 py-2 text-sm rounded-md text-gray-600 hover:bg-gray-50 transition-colors"
                            onClick={() => setIsCurrencyMenuOpen(false)}
                          >
                            <span className="font-medium">{currency.code}</span>
                            <span className="text-gray-500">{currency.name}</span>
                          </button>
                        ))}
                      </div>

                      {/* More Currencies */}
                      <div className="px-4 py-2 border-t border-b border-gray-100">
                        <h3 className="font-semibold text-gray-900">More currencies</h3>
                      </div>
                      <div className="grid grid-cols-3 gap-1 p-2 max-h-[320px] overflow-y-auto">
                        {moreCurrencies.map((currency) => (
                          <button
                            key={currency.code}
                            className={`flex items-center space-x-2 px-3 py-2 text-sm rounded-md transition-colors
                              ${currency.code === 'EUR'
                                ? 'text-orange-500 bg-orange-50'
                                : 'text-gray-600 hover:bg-gray-50'
                              }`}
                            onClick={() => setIsCurrencyMenuOpen(false)}
                          >
                            <span className="font-medium">{currency.code}</span>
                            <span className="text-gray-500">{currency.name}</span>
                          </button>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                <button className="flex items-center space-x-1 text-gray-600 hover:text-orange-500">
                  <Smartphone className="h-4 w-4" />
                  <span>Go to app</span>
                </button>
                <button className="flex items-center space-x-1 text-gray-600 hover:text-orange-500">
                  <HelpCircle className="h-4 w-4" />
                  <span>Help</span>
                </button>
                <button className="flex items-center space-x-1 text-gray-600 hover:text-orange-500">
                  <Clock className="h-4 w-4" />
                  <span>Recently viewed</span>
                </button>
                <button className="text-gray-600 hover:text-orange-500">
                  Sign up
                </button>
                <button className="bg-orange-500 text-white px-6 py-2 rounded-full hover:bg-orange-600 transition-colors">
                  Log in
                </button>
              </div>
            </nav>
          </div>

          {/* Secondary Navigation */}
          <div className="hidden lg:flex items-center space-x-6 py-2 text-sm">
            <button className="flex items-center space-x-1 text-gray-600 hover:text-orange-500">
              <CircleIcon className="h-3 w-3" />
              <span>Explore destinations</span>
            </button>
            <button className="text-gray-600 hover:text-orange-500">All categories</button>
            <button className="text-gray-600 hover:text-orange-500">Tours & experiences</button>
            <button className="text-gray-600 hover:text-orange-500">Attraction tickets</button>
            <button className="text-gray-600 hover:text-orange-500">Hotels</button>
            <button className="text-gray-600 hover:text-orange-500">Transport</button>
            <button className="text-gray-600 hover:text-orange-500">Car rentals</button>
            <button className="text-gray-600 hover:text-orange-500">Gift cards</button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <div className="relative h-[600px]">
        {/* Background Image */}
        <div 
          className="absolute inset-0 bg-cover bg-center"
          style={{
            backgroundImage: 'url("https://images.unsplash.com/photo-1545569341-9eb8b30979d9?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=2340&q=80")',
          }}
        >
          <div className="absolute inset-0 bg-black bg-opacity-40" />
        </div>

        {/* Decorative Elements */}
        <div className="absolute left-0 top-1/4 w-32 h-32 bg-orange-500 opacity-20 rounded-full blur-3xl" />
        <div className="absolute right-0 bottom-1/4 w-32 h-32 bg-teal-500 opacity-20 rounded-full blur-3xl" />

        {/* Hero Content */}
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 h-full">
          <div className="flex flex-col justify-center h-full space-y-8">
            <div className="space-y-4 text-center">
              <h2 className="text-5xl font-bold text-white">
                Your world of joy
              </h2>
              <p className="text-xl text-white max-w-2xl mx-auto">
                From local escapes to far-flung adventures, find what makes you happy anytime, anywhere.
              </p>
            </div>

            {/* Search Form */}
            <div className="max-w-2xl mx-auto w-full">
              <div className="flex">
                <div className="relative flex-grow">
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="disneysea tokyo"
                    className="w-full pl-12 pr-4 py-4 rounded-l-lg focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent text-lg"
                  />
                  <MapPin className="absolute left-4 top-4 h-6 w-6 text-gray-400" />
                </div>
                <button className="bg-orange-500 text-white px-8 rounded-r-lg text-lg font-medium hover:bg-orange-600 transition-colors">
                  Search
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;